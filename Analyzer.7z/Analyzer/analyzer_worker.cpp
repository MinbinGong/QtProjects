#include "analyzer_worker.h"

#include <QMessageBox>

#include <opencv2/opencv.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/video/background_segm.hpp>
#include <opencv2/features2d.hpp>
#include <opencv2/flann/miniflann.hpp>

#include <algorithm>
#include <vector>

analyzer_worker::analyzer_worker()
{

}

bool analyzer_worker::execute(QWidget *parent, const QString &reference, const QImage &target)
{
    Q_UNUSED(parent);
    Q_UNUSED(target);

    cv::Mat image_src = cv::imread(reference.toStdString(), cv::IMREAD_COLOR);
    cv::Mat image_ref = prepare_image(image_src);
    if (image_ref.empty()) {
        return false;
    }
//    cv::namedWindow("Reference Image");
//    cv::imshow("Reference Image", image_ref);

//    cv::Mat target_img = convert_opencv_mat(target);
    cv::Mat target_img = cv::imread("C:/Users/gongw/workspace/Resources/original.jpg", cv::IMREAD_COLOR);
    cv::Mat image_target = prepare_image(target_img);
//    cv::namedWindow("Target Image");
//    cv::imshow("Target Image", image_target);

    return compare_image(image_ref, image_target);
//    return true;
}

cv::Mat analyzer_worker::convert_opencv_mat(const QImage &in_image, bool clone_data)
{
    switch ( in_image.format() )
    {
    // 8-bit, 4 channel
    case QImage::Format_ARGB32:
    case QImage::Format_ARGB32_Premultiplied:
    {
        cv::Mat  mat( in_image.height(), in_image.width(),
                      CV_8UC4,
                      const_cast<uchar*>(in_image.bits()),
                      static_cast<size_t>(in_image.bytesPerLine())
                      );

        return (clone_data ? mat.clone() : mat);
    }
    // 8-bit, 3 channel
    case QImage::Format_RGB32:
    case QImage::Format_RGB888:
    {
        if ( !clone_data )
        {
        }

        QImage   swapped = in_image;

        if ( in_image.format() == QImage::Format_RGB32 )
        {
            swapped = swapped.convertToFormat( QImage::Format_RGB888 );
        }

        swapped = swapped.rgbSwapped();

        return cv::Mat( swapped.height(), swapped.width(),
                        CV_8UC3,
                        const_cast<uchar*>(swapped.bits()),
                        static_cast<size_t>(swapped.bytesPerLine())
                        ).clone();
    }

    // 8-bit, 1 channel
    case QImage::Format_Indexed8:
    {
        cv::Mat  mat( in_image.height(), in_image.width(),
                      CV_8UC1,
                      const_cast<uchar*>(in_image.bits()),
                      static_cast<size_t>(in_image.bytesPerLine())
                      );

        return (clone_data ? mat.clone() : mat);
    }

    default:
        break;
    }

    return cv::Mat();
}

bool analyzer_worker::compare_image(const cv::Mat &src, const cv::Mat &dst)
{
    cv::Mat ret = match_result(src, dst);
    cv::namedWindow("Result Image");
    cv::imshow("Result Image", ret);

    return true;
}

cv::Mat analyzer_worker::prepare_image(cv::Mat& input)
{
    return input;
//    cv::Mat bgra_input;
//    cv::cvtColor(input, bgra_input, cv::COLOR_BGR2BGRA);

//    cv::Mat blur_img;
//    cv::GaussianBlur(bgra_input, blur_img, cv::Size(0,0), 25);

//    cv::Mat usm;
//    cv::addWeighted(bgra_input, 1.5, blur_img, -0.5, 0, usm);

//    cv::Mat roi = cv::Mat(cv::Size(bgra_input.cols, bgra_input.rows), CV_8UC3,
//                          cv::Scalar(255, 255, 255));

//    cv::Mat dst;
//    cv::addWeighted(usm, 1.275, roi, 0.00015, 0, dst);
//    return dst;

//    cv::resize(bgra_input, bgra_input, cv::Size(0,0), 0.5, 0.5);

//    cv::Mat src;
//    cv::threshold(bgra_input, src, 200, 255, cv::THRESH_TRUNC);
//    cv::threshold(src, src, 100, 255, cv::THRESH_TOZERO);

//    std::vector<std::vector<cv::Point>> contours;
//    std::vector<cv::Vec4i> hierarchy;
//    cv::findContours(src, contours, hierarchy, cv::RETR_LIST, cv::CHAIN_APPROX_NONE, cv::Point(0,0));

//    cv::Mat dst;
//    cv::drawContours(dst, contours, -1, cv::Scalar::all(255));

//    return dst;
}


std::vector<double> analyzer_worker::calculate_hist(const cv::Mat &src, const cv::Mat &templ)
{
    cv::Mat hsv_src, hsv_templ;

    cv::cvtColor(src, hsv_src, CV_BGR2HSV);
    cv::cvtColor(templ, hsv_templ, CV_BGR2HSV);

    int hist_size[] = {256, 256};
    float h_ranges[] = {0, 256};
    float s_ranges[] = {0, 180};
    const float* ranges[] = {h_ranges, s_ranges};
    int channels[] = {0, 1};

    cv::Mat hist_src;
    cv::calcHist(&hsv_src, 1, channels, cv::Mat(), hist_src, 2, hist_size, ranges, true, false);
    cv::normalize(hist_src, hist_src, 0, 1, cv::NORM_MINMAX, -1, cv::Mat());

    cv::Mat hist_templ;
    cv::calcHist(&hsv_templ, 1, channels, cv::Mat(), hist_templ, 2, hist_size, ranges, true, false);
    cv::normalize(hist_templ, hist_templ, 0, 1, cv::NORM_MINMAX, -1, cv::Mat());

    std::vector<double> results{};
    for (int i = 0; i < 4; ++i) {
        double src_templ = cv::compareHist(hist_src, hist_templ, i);
        results.push_back(src_templ);
    }
    return results;
}

cv::Mat analyzer_worker::match_result(const cv::Mat& src, const cv::Mat& dst)
{
    cv::Ptr<cv::ORB> detector = cv::ORB::create(400);
    std::vector<cv::KeyPoint> keypointsObj;
    std::vector<cv::KeyPoint> keypointsScene;
    cv::Mat dscObj, dscScene;
    detector->detectAndCompute(src, cv::Mat(), keypointsObj, dscObj);
    detector->detectAndCompute(dst, cv::Mat(), keypointsScene, dscScene);

    cv::FlannBasedMatcher fbMatcher(new cv::flann::LshIndexParams(20, 10, 2));
    std::vector<cv::DMatch> matches;
    fbMatcher.match(dscObj, dscScene, matches);

    double minDist = 1000, maxDist = 0;
    std::vector<cv::DMatch> goodMatches;
    for (int i = 0; i < dscObj.rows; ++i) {
        double dist = matches[i].distance;
        if (dist < minDist) {
            minDist = dist;
        }

        if (dist > maxDist) {
            maxDist = dist;
        }
    }

    for (int i = 0; i < dscObj.rows; ++i) {
        double dist = matches[i].distance;
        if (dist < std::max(2*minDist, 0.02)) {
            goodMatches.push_back(matches[i]);
        }
    }

    cv::Mat orbImg;
    cv::drawMatches(src, keypointsObj, dst, keypointsScene, goodMatches, orbImg,
                    cv::Scalar::all(-1), cv::Scalar::all(-1),
                    std::vector<char>(),
                    cv::DrawMatchesFlags::NOT_DRAW_SINGLE_POINTS);

    return orbImg;
}
