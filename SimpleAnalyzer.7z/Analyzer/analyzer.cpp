#include "analyzer.h"
#include "ui_analyzer.h"

#include <QDebug>

Analyzer::Analyzer(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Analyzer)
{
    ui->setupUi(this);

    QComboBox *cameraType = new QComboBox();
    cameraType = ui->cameraType;
    cameraType->clear();

    cameras = QCameraInfo::availableCameras();
    QList<QCameraInfo> cameras = QCameraInfo::availableCameras();
    foreach(const QCameraInfo &cameraInfo, cameras) {
//        qDebug() << "CameraInfo:" << cameraInfo;
        cameraType->addItem(cameraInfo.description());
    }

    camera = new QCamera(this);
    viewfinder = new QCameraViewfinder();
    viewfinder->show();
    camera->setViewfinder(viewfinder);
    imageCapture = new QCameraImageCapture(camera);
    camera->start();

    connect(imageCapture, SIGNAL(imageCaptured(int, QImage)), this, SLOT(on_imageCaptured(int, QImage)));
}

Analyzer::~Analyzer()
{
    delete ui;
}


void Analyzer::on_cameraType_activated(int index)
{
    index = ui->cameraType->currentIndex();
    qDebug()<<"Index"<< index <<": "<< ui->cameraType->currentText();
    camera->stop();
    camera = new QCamera(cameras[index]);
    camera->setCaptureMode(QCamera::CaptureVideo);
    camera->setViewfinder(viewfinder);
    camera->start();
}

void Analyzer::on_snapshot_clicked()
{
    qDebug() << "snapshot";

    imageCapture->capture();
}

void Analyzer::on_imageCaptured(int id, const QImage &preview)
{
    Q_UNUSED(id);
    int width = ui->majorView->width();
    int height = ui->majorView->height();
    QPixmap pixmap = QPixmap::fromImage(preview);
    QPixmap fitPixmap = pixmap.scaled(width, height, Qt::KeepAspectRatio, Qt::SmoothTransformation);
    ui->majorView->setPixmap(fitPixmap);
}
