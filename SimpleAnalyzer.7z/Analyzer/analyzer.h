#ifndef ANALYZER_H
#define ANALYZER_H

#include <QMainWindow>
#include <QCamera>
#include <QCameraViewfinder>
#include <QCameraInfo>
#include <QCameraImageCapture>

QT_BEGIN_NAMESPACE
namespace Ui { class Analyzer; }
QT_END_NAMESPACE

class Analyzer : public QMainWindow
{
    Q_OBJECT

public:
    Analyzer(QWidget *parent = nullptr);
    ~Analyzer();

private slots:
    void on_cameraType_activated(int index);

    void on_snapshot_clicked();

    void on_imageCaptured(int id, const QImage &preview);

private:
    Ui::Analyzer *ui;
    QCamera *camera;
    QCameraViewfinder *viewfinder;
    QList<QCameraInfo> cameras;
    QCameraImageCapture *imageCapture;
};
#endif // ANALYZER_H
